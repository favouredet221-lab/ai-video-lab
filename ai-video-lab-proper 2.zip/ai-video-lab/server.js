import express from 'express';
import path from 'path';
import {fileURLToPath} from 'url';
const app=express(); const __filename=fileURLToPath(import.meta.url); const __dirname=path.dirname(__filename);
app.use(express.json()); app.use(express.static(path.join(__dirname,'public')));
app.get('/api/health',(_,res)=>res.json({ok:true,app:'AI Video Lab'}));
app.post('/api/generate',(req,res)=>{const {idea,style,format,voice}=req.body||{}; if(!idea?.trim()) return res.status(400).json({error:'Please enter a video idea.'}); res.json({status:'queued',message:'Your 60-second video request has been received.',settings:{idea,style,format,voice}})});
app.listen(process.env.PORT||3000);
